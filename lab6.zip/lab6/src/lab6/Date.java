package lab6;

public class Date {
	
	private int day;
	private int month;
	private int year;
	
	/**
	 * @param day set day
	 * @param month set month
	 * @param year set year
	 */
	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	/**
	 * @return the day
	 */
	public final int getDay() {
		return day;
	}

	/**
	 * @param day the day to set
	 */
	public final void setDay(int day) {
		this.day = day;
	}

	/**
	 * @return the month
	 */
	public final int getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public final void setMonth(int month) {
		this.month = month;
	}

	/**
	 * @return the year
	 */
	public final int getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public final void setYear(int year) {
		this.year = year;
	}
	
	public String getDayOfTheWeek(int day, int month, int year) {
		int y = year % 100;
		int first = y / 12;
		int second = y % 12;
		int third = second / 4;
		int fourth = day;
		int fifth = getDateCode(month);
		int yf = year / 100;
		
		if(yf == 16 || yf == 20) {
			fifth = fifth + 6;
		}else if(yf == 17 || yf == 21) {
			fifth = fifth + 4;
		}else if(yf == 18) {
			fifth = fifth + 2;
		}
		
		if(isLeapYear(year) && (month == 1 || month == 2)){		
			fifth = fifth - 1;
		}
		int last = (first + second + third + fourth + fifth) % 7;
		switch(last) {
		case 0:
			return "Saturday";
		case 1:
			return "Sunday";
		case 2:
			return "Monday";
		case 3:
			return "Tuesday";
		case 4:
			return "Wednesday";
		case 5:
			return "Thursday";
		case 6:
			return "Friday";
		default:
			return "Invalid";
			
		}
	}
	
	private int getDateCode(int month) {
		if(month == 1 || month == 10) {
			return 1;
		}
		else if(month == 2 || month == 3 || month == 11){
			return 4;
		}
		else if(month == 4 || month == 7) {
			return 0;
		}
		else if(month == 5) {
			return 2;
		}
		else if(month == 6) {
			return 5;
		}
		else if(month == 8) {
			return 3;
		}
		else {
			return 6;
		}
	}

	
	private boolean isLeapYear(int year) {
		if (year % 4 != 0) {
		    return false;
		  } else if (year % 400 == 0) {
		    return true;
		  } else if (year % 100 == 0 && year % 400 != 0) {
		    return false;
		  } else {
		    return true;
		  }
	}
	
	public boolean validDate(int day, int month, int year) {
		if(isLeapYear(year)) {
			if (month == 2 && day > 29) {
				return false;
			}
			return true;
		}else {
			if (month == 2 && day > 28) {
				return false;
			}
			return true;
		}	
	}
}
