package lab6;

public class Driver {
	private static View v;
	public static void main(String[] args) {
		v = new View();
		for(int n = 1; n <= 100; n++) {
			String da = v.askForDate();
			if(da.equals("quit")) {
				System.exit(0);
			}
			else {
				String[] dd = da.split("-");
				int y = Integer.parseInt(dd[0]);
				int m = Integer.parseInt(dd[1]);
				int d = Integer.parseInt(dd[2]);
				Date date = new Date(d, m, y);
				if(date.validDate(d, m, y)) {
					System.out.println(date.getDayOfTheWeek(d, m, y));
				}
				else {
					System.out.println("Invalid date");
				}
			}
		}
	}
}
