package lab6;

public class View {
	private InputReader reader;
	public View() {
		reader = new InputReader();
	}
	
	public String askForDate() {
		String a  = reader.getStringInput();
		return a;
	}
}
